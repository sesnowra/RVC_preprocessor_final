@echo off
chcp 65001 >nul 2>nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
if not exist "%~dp0mp3_tool.py" goto nofile
set PY=
py -3 -c "import sys; sys.exit(0 if sys.version_info[0]>=3 else 1)" >nul 2>nul
if not errorlevel 1 set PY=py -3
if defined PY goto run
python3 -c "import sys; sys.exit(0 if sys.version_info[0]>=3 else 1)" >nul 2>nul
if not errorlevel 1 set PY=python3
if defined PY goto run
python -c "import sys; sys.exit(0 if sys.version_info[0]>=3 else 1)" >nul 2>nul
if not errorlevel 1 set PY=python
if defined PY goto run
echo [ERROR] Python 3 was not found. Install Python 3 and add it to PATH.
echo Press any key to exit...
pause >nul
exit /b 1
:nofile
echo [ERROR] mp3_tool.py is not in the same folder as this file.
echo Press any key to exit...
pause >nul
exit /b 1
:run
%PY% "%~dp0mp3_tool.py"
exit /b %errorlevel%
