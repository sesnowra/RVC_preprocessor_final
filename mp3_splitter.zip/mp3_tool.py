# -*- coding: utf-8 -*-
"""
MP3 분할 + 묵음 제거 도구 (버전 독립형)
- 이 파일이 있는 폴더(루트)의 모든 .mp3를 9분 미만 조각으로 분할
- 각 조각의 묵음을 0.1초만 남기고 제거
- 모든 결과물의 무결성 검사 통과 시: 결과물을 루트로 이동 -> 원본 삭제 -> 자동 종료
- 오류 발생 시: 원본은 그대로 두고 오류 이유 출력 -> 아무 키나 눌러 종료

호환성
- Python 3.0 이상 모든 버전 (Python 2는 안내 메시지를 띄우고 종료)
- ffmpeg 1.0(2012) 이후 모든 버전: 버전마다 동작이 달라지는 silenceremove 필터를
  쓰지 않고, 묵음 제거를 파이썬에서 직접 처리합니다.
- Windows / macOS / Linux 공통
"""
from __future__ import print_function

import os
import sys

# ===== 설정 =====
MAX_SEG = 535.0          # 분할할 때 조각 최대 길이(초)
LIMIT = 539.5            # 이보다 짧은 원본은 분할하지 않음 (9분 = 540초 미만 보장)
KEEP_SILENCE = 0.1       # 남길 묵음 길이(초)
THRESHOLD_DB = -50.0     # 이 값 이하의 소리를 묵음으로 판단 (dBFS)
TMP_NAME = "_mp3_work_tmp"
DEFAULT_BITRATE = "192k"
# ================


def safe_print(msg="", err=False):
    stream = sys.stderr if err else sys.stdout
    try:
        stream.write(msg + "\n")
    except Exception:
        try:
            enc = getattr(stream, "encoding", None) or "ascii"
            stream.write(msg.encode(enc, "replace").decode(enc, "replace") + "\n")
        except Exception:
            try:
                stream.buffer.write((msg + "\n").encode("utf-8", "replace"))
            except Exception:
                pass
    try:
        stream.flush()
    except Exception:
        pass


def wait_key():
    safe_print("\n아무 키나 누르면 종료합니다...")
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.getch()
            return
        import termios
        import tty
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    except Exception:
        try:
            if sys.version_info[0] < 3:
                raw_input()  # noqa: F821
            else:
                input()
        except Exception:
            pass


# Python 2 등 지원하지 않는 버전은 여기서 안내 후 종료
if sys.version_info[0] < 3:
    safe_print("[오류] Python 3 이상이 필요합니다. 현재 버전: %d.%d" % sys.version_info[:2], True)
    wait_key()
    sys.exit(1)

import json
import math
import shutil
import operator
import subprocess
from array import array


class ToolError(Exception):
    pass


DEVNULL = open(os.devnull, "wb")
BIG_ENDIAN = sys.byteorder == "big"
THR_AMP = 32768 * (10 ** (THRESHOLD_DB / 20.0))
THR_SQ = THR_AMP * THR_AMP          # 블록 평균 제곱(RMS^2) 기준
IS_WIN = os.name == "nt"


def find_exe(name):
    """shutil.which 대체 (Python 3.0~3.2에도 동작)"""
    exts = [""]
    if IS_WIN:
        exts = os.environ.get("PATHEXT", ".EXE;.BAT;.CMD").lower().split(";") + [""]
    for d in os.environ.get("PATH", "").split(os.pathsep):
        d = d.strip('"')
        if not d:
            continue
        for e in exts:
            p = os.path.join(d, name + e)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None


def run(cmd):
    p = subprocess.Popen(cmd, stdin=DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    return p.returncode, out.decode("utf-8", "replace"), err.decode("utf-8", "replace")


FFMPEG = None
FFPROBE = None


def check_tools():
    global FFMPEG, FFPROBE
    FFMPEG = find_exe("ffmpeg")
    FFPROBE = find_exe("ffprobe")
    if not FFMPEG:
        raise ToolError("ffmpeg를 찾을 수 없습니다. ffmpeg 설치 및 PATH 등록을 확인하세요.")
    if not FFPROBE:
        raise ToolError("ffprobe를 찾을 수 없습니다. ffmpeg 전체 패키지(ffprobe 포함)를 설치하세요.")
    rc, out, err = run([FFMPEG, "-encoders"])
    if rc == 0 and "Encoders" in out and "libmp3lame" not in out:
        raise ToolError("ffmpeg에 MP3 인코더(libmp3lame)가 없습니다. 전체 기능 빌드의 ffmpeg를 설치하세요.")


def probe(path):
    rc, out, err = run([FFPROBE, "-v", "error", "-print_format", "json",
                        "-show_format", "-show_streams", "-select_streams", "a:0", path])
    name = os.path.basename(path)
    if rc != 0:
        raise ToolError("파일 분석 실패: %s\n  %s" % (name, err.strip()))
    try:
        data = json.loads(out or "{}")
    except ValueError:
        raise ToolError("파일 분석 결과를 읽을 수 없습니다: %s" % name)
    streams = [s for s in (data.get("streams") or []) if s.get("codec_type", "audio") == "audio"]
    if not streams:
        raise ToolError("오디오 스트림이 없습니다: %s" % name)
    st = streams[0]
    fmt = data.get("format") or {}

    def num(v, conv, default):
        try:
            return conv(v)
        except (TypeError, ValueError):
            return default

    dur = num(fmt.get("duration"), float, 0.0) or num(st.get("duration"), float, 0.0)
    sr = num(st.get("sample_rate"), int, 0) or 44100
    ch = num(st.get("channels"), int, 0) or 2
    br = num(st.get("bit_rate"), int, 0) or num(fmt.get("bit_rate"), int, 0)
    return dur, sr, ch, br


def bitrate_arg(br, ch):
    if not br:
        return DEFAULT_BITRATE
    floor = 64 if ch == 1 else 128            # VBR 원본은 평균이 낮게 잡혀 음질 저하 방지
    kbps = max(floor, min(320, int(round(br / 1000.0))))
    return "%dk" % kbps


def to_array(raw):
    a = array("h")
    if hasattr(a, "frombytes"):  # novermin
        a.frombytes(raw)
    else:
        a.fromstring(raw)
    if BIG_ENDIAN:
        a.byteswap()
    return a


def remove_silence(data, sr, ch):
    """16bit PCM(little-endian)에서 묵음 구간을 KEEP_SILENCE초만 남기고 제거.
    10ms 블록의 RMS가 THRESHOLD_DB 이하이면 묵음으로 판정."""
    fb = 2 * ch                      # 프레임당 바이트
    bf = max(1, sr // 100)           # 10ms 블록당 프레임
    bb = bf * fb                     # 블록당 바이트
    spb = bf * ch                    # 블록당 샘플 수
    nblk = (len(data) + bb - 1) // bb
    if nblk == 0:
        return b""

    silent = []
    batch = bb * 100
    for off in range(0, len(data), batch):
        a = to_array(data[off:off + batch])
        for s in range(0, len(a), spb):
            sl = a[s:s + spb]
            if len(sl) == 0:
                continue
            # RMS 기준: 압축 잡음 같은 짧은 튐에 흔들리지 않음
            silent.append(sum(map(operator.mul, sl, sl)) <= THR_SQ * len(sl))
    nblk = len(silent)

    K = max(1, int(round(KEEP_SILENCE / 0.01)))
    keep = [False] * nblk
    i = 0
    while i < nblk:
        if not silent[i]:
            keep[i] = True
            i += 1
            continue
        j = i
        while j < nblk and silent[j]:
            j += 1
        L = j - i
        if i == 0 and j == nblk:
            pass                                   # 전체가 묵음
        elif L <= K:
            for k in range(i, j):
                keep[k] = True
        elif i == 0:                               # 앞쪽 묵음: 소리 직전 K블록
            for k in range(j - K, j):
                keep[k] = True
        elif j == nblk:                            # 뒤쪽 묵음: 소리 직후 K블록
            for k in range(i, i + K):
                keep[k] = True
        else:                                      # 중간 묵음: 앞뒤 절반씩
            h = K // 2
            for k in list(range(i, i + h)) + list(range(j - (K - h), j)):
                keep[k] = True
        i = j

    parts = []
    i = 0
    while i < nblk:
        if keep[i]:
            j = i
            while j < nblk and keep[j]:
                j += 1
            parts.append(data[i * bb:min(j * bb, len(data))])
            i = j
        else:
            i += 1
    return b"".join(parts)


def read_exact(stream, n):
    buf = []
    got = 0
    while got < n:
        piece = stream.read(min(n - got, 1 << 20))
        if not piece:
            break
        buf.append(piece)
        got += len(piece)
    return b"".join(buf)


def encode(pcm, sr, ch, bitrate, src, out):
    cmd = [FFMPEG, "-v", "error", "-y",
           "-f", "s16le", "-ar", str(sr), "-ac", str(ch), "-i", "-",
           "-i", src, "-map", "0:a", "-map_metadata", "1",
           "-c:a", "libmp3lame", "-b:a", bitrate, out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=DEVNULL, stderr=subprocess.PIPE)
    _, err = p.communicate(pcm)
    if p.returncode != 0:
        raise ToolError("MP3 인코딩 실패: %s\n  %s" % (os.path.basename(out),
                                                    err.decode("utf-8", "replace").strip()))


def process_file(src, tmp):
    name = os.path.basename(src)
    stem = os.path.splitext(name)[0]
    dur, sr, ch, br = probe(src)
    if dur <= 0:
        raise ToolError("재생 길이를 알 수 없습니다: %s" % name)
    n = 1 if dur <= LIMIT else int(math.ceil(dur / MAX_SEG))
    seg_frames = int(math.ceil(dur * sr / n))
    seg_frames = min(seg_frames, int(LIMIT * sr))
    fb = 2 * ch
    bitrate = bitrate_arg(br, ch)
    safe_print("\n[%s] 길이 %.1f초 → %d개로 분할 (%s)" % (name, dur, n, bitrate))

    errlog = os.path.join(tmp, "_decode_err.txt")
    ef = open(errlog, "wb")
    dec = subprocess.Popen([FFMPEG, "-v", "error", "-i", src, "-map", "0:a:0", "-vn",
                            "-f", "s16le", "-acodec", "pcm_s16le",
                            "-ar", str(sr), "-ac", str(ch), "-"],
                           stdin=DEVNULL, stdout=subprocess.PIPE, stderr=ef)
    outputs = []
    idx = 0
    decoded_frames = 0
    try:
        while True:
            pcm = read_exact(dec.stdout, seg_frames * fb)
            if not pcm:
                break
            pcm = pcm[:len(pcm) - len(pcm) % fb]
            decoded_frames += len(pcm) // fb
            idx += 1
            cleaned = remove_silence(pcm, sr, ch)
            if len(cleaned) < fb * (sr // 20):     # 0.05초 미만 = 사실상 전부 묵음
                safe_print("  - 조각 %d: 전부 묵음이라 제외" % idx)
                continue
            out = os.path.join(tmp, "%s_%03d.mp3" % (stem, idx))
            encode(cleaned, sr, ch, bitrate, src, out)
            safe_print("  - %s: %.1f초" % (os.path.basename(out), len(cleaned) / float(fb * sr)))
            outputs.append(out)
    finally:
        try:
            dec.stdout.close()
        except Exception:
            pass
        dec.wait()
        ef.close()
    if dec.returncode != 0:
        with open(errlog, "rb") as f:
            msg = f.read().decode("utf-8", "replace").strip()
        raise ToolError("디코딩 실패: %s\n  %s" % (name, msg or "원인 불명"))
    decoded = decoded_frames / float(sr)
    if decoded < dur * 0.9:
        raise ToolError("파일이 손상되었거나 잘린 것으로 보입니다: %s\n"
                        "  표시된 길이 %.1f초 중 %.1f초만 읽을 수 있습니다." % (name, dur, decoded))
    if not outputs:
        raise ToolError("결과물이 없습니다(전체가 묵음으로 판단됨): %s" % name)
    return outputs


def verify(path):
    """무결성 검사. 문제 있으면 이유 문자열, 정상이면 None."""
    if not os.path.isfile(path) or os.path.getsize(path) == 0:
        return "파일이 없거나 크기가 0입니다"
    try:
        dur = probe(path)[0]
    except ToolError as e:
        return str(e)
    if dur <= 0:
        return "재생 길이를 확인할 수 없습니다"
    if dur >= 540:
        return "길이가 9분 이상입니다 (%.1f초)" % dur
    rc, out, err = run([FFMPEG, "-v", "error", "-i", path, "-f", "null", "-"])
    if rc != 0 or err.strip():
        return "디코딩 오류: " + (err.strip().splitlines() or ["알 수 없음"])[0]
    return None


def main():
    root = os.path.dirname(os.path.abspath(__file__))
    os.chdir(root)
    check_tools()

    sources = sorted(os.path.join(root, f) for f in os.listdir(root)
                     if f.lower().endswith(".mp3") and os.path.isfile(os.path.join(root, f)))
    if not sources:
        raise ToolError("처리할 .mp3 파일이 없습니다: %s" % root)
    seen = {}
    for src in sources:
        key = os.path.splitext(os.path.basename(src))[0].lower()
        if key in seen:
            raise ToolError("이름이 대소문자/확장자만 다른 파일이 있어 결과 이름이 겹칩니다 (원본은 보존됨):\n  %s\n  %s"
                            % (os.path.basename(seen[key]), os.path.basename(src)))
        seen[key] = src

    tmp = os.path.join(root, TMP_NAME)
    if os.path.isdir(tmp):
        shutil.rmtree(tmp)
    os.mkdir(tmp)

    try:
        # 1) 분할 + 묵음 제거
        all_outputs = []
        for src in sources:
            all_outputs.extend(process_file(src, tmp))

        # 2) 무결성 검사
        safe_print("\n무결성 검사 중...")
        failures = []
        for out in all_outputs:
            reason = verify(out)
            if reason:
                failures.append("%s: %s" % (os.path.basename(out), reason))
        if failures:
            raise ToolError("무결성 검사 실패 (원본은 보존됨):\n  " + "\n  ".join(failures))
        safe_print("  %d개 파일 모두 통과" % len(all_outputs))

        # 3) 이름 충돌 확인
        existing = set(f.lower() for f in os.listdir(root))
        clashes = [os.path.basename(o) for o in all_outputs
                   if os.path.basename(o).lower() in existing]
        if clashes:
            raise ToolError("루트에 같은 이름의 파일이 이미 있습니다 (원본은 보존됨):\n  "
                            + "\n  ".join(clashes))

        # 4) 결과물 이동 -> 원본 삭제
        moved = []
        try:
            for out in all_outputs:
                dst = os.path.join(root, os.path.basename(out))
                shutil.move(out, dst)
                moved.append(dst)
        except (IOError, OSError) as e:
            for dst in moved:                      # 실패 시 이미 옮긴 결과물 되돌림
                try:
                    os.remove(dst)
                except OSError:
                    pass
            raise ToolError("결과물을 폴더로 옮기지 못했습니다 (원본은 보존됨): %s" % e)
        for src in sources:
            os.remove(src)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    safe_print("\n완료: 원본 %d개 → 결과 %d개" % (len(sources), len(all_outputs)))


if __name__ == "__main__":
    try:
        main()
        sys.exit(0)
    except ToolError as e:
        safe_print("\n[오류] %s" % e, True)
    except KeyboardInterrupt:
        safe_print("\n[오류] 사용자가 중단했습니다.", True)
    except (IOError, OSError) as e:
        en = getattr(e, "errno", None)
        why = {13: "권한이 없습니다(폴더 쓰기 권한 또는 다른 프로그램이 파일을 사용 중인지 확인)",
               28: "디스크 공간이 부족합니다",
               2: "파일 또는 폴더를 찾을 수 없습니다"}.get(en, "파일 처리 중 시스템 오류가 발생했습니다")
        safe_print("\n[오류] %s\n  상세: %s" % (why, e), True)
    except Exception as e:
        import traceback
        safe_print("\n[오류] 예기치 못한 오류: %s: %s" % (type(e).__name__, e), True)
        safe_print(traceback.format_exc(), True)
    wait_key()
    sys.exit(1)
