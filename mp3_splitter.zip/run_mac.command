#!/bin/bash
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:/opt/local/bin:$PATH"
export PYTHONIOENCODING=utf-8
fail() { echo "[오류] $1"; echo "아무 키나 누르면 종료합니다..."; read -n 1 -s; exit 1; }
[ -f mp3_tool.py ] || fail "mp3_tool.py 파일이 같은 폴더에 없습니다."
PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info[0]>=3 else 1)' >/dev/null 2>&1; then
    PY="$c"; break
  fi
done
[ -n "$PY" ] || fail "Python 3를 찾을 수 없습니다. Python 3를 설치하세요."
"$PY" mp3_tool.py
exit $?
